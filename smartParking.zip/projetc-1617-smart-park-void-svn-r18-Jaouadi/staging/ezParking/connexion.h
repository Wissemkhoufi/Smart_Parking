#ifndef CONNEXION_H
#define CONNEXION_H
#include <QSqlDatabase>


class Connexion
{
public:
    Connexion();
    bool createConnexion();
    QSqlDatabase db;
private:

};

#endif // CONNEXION_H
