#include "adduser.h"
#include "ui_adduser.h"
#include "espaceadmin.h"
#include <QDebug>
#include <QMessageBox>
AddUser::AddUser(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddUser)
{
    ui->setupUi(this);
}

AddUser::~AddUser()
{
    delete ui;
}

void AddUser::on_buttonBox_accepted()
{
    QString l=ui->login_2->text();
    QString m=ui->pass->text();
    QString m2=ui->pass2->text();
    QMessageBox message;
    AddUser addUser;
    EspaceAdmin espaceAdmin;
    int t=0;

    addUser.setModal(true);
    espaceAdmin.setModal(true);


    if (m!=m2)
    {
        message.setText("les deux mots de passes ne sont pas identiques.");
        message.exec();
        addUser.exec();
    }
    else if (!(ui->boutonAdmin->isChecked() || ui->boutonUser->isChecked()))
    {
        message.setText("Veuillez choisir le type de compte.");
        message.exec();
        addUser.exec();
    }
    else
    {
        if (ui->boutonAdmin->isChecked())
            t=1;
        Compte C(l,m,t);
        if(C.ajouterUtilisateur())
           {
            message.setText("Utilisateur ajouté.");
            message.exec();
            hide();
            espaceAdmin.exec();
               }
        else
        {
            message.setText("Login existant !");
            message.exec();
            addUser.exec();
        }
    }
}

void AddUser::on_buttonBox_rejected()
{
    hide();
    EspaceAdmin espaceAdmin;
    espaceAdmin.setModal(true);
    espaceAdmin.exec();
}
