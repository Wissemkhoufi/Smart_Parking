#include "espaceadmin.h"
#include "ui_espaceadmin.h"
#include "adduser.h"
#include "updateaccount.h"
#include "addobject.h"
#include "updateobject.h"
#include "consulterstat.h"
#include "etatactuel.h"
#include "Place.h"
#include "voiture.h"
#include "connexion.h"
#include <QSqlQueryModel>
#include <QMessageBox>


EspaceAdmin::EspaceAdmin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::EspaceAdmin)
{
    ui->setupUi(this);
}

EspaceAdmin::~EspaceAdmin()
{
    delete ui;
}


void EspaceAdmin::on_updAcc_clicked()
{
    hide();
    UpdateAccount updateAccount;
    updateAccount.setModal(true);
    updateAccount.exec();
}

void EspaceAdmin::on_addUser_clicked()
{
    hide();
    AddUser addUser;
    addUser.setModal(true);
    addUser.exec();
}

void EspaceAdmin::on_addObj_clicked()
{
    hide();
    AddObject addObj;
    addObj.setModal(true);
    addObj.exec();
}

void EspaceAdmin::on_updObj_clicked()
{
    hide();
    UpdateObject updObj;
    updObj.setModal(true);
    updObj.exec();
}

void EspaceAdmin::on_stat_clicked()
{
    hide();
    ConsulterStat consulterStat;
    consulterStat.setModal(true);
    consulterStat.exec();
}

void EspaceAdmin::on_statePark_clicked()
{
    hide();
    EtatActuel etatActuel;
    etatActuel.setModal(true);
    etatActuel.exec();
}



void EspaceAdmin::on_pushButton_clicked()
{
    hide ();
    Place place;
    place.setModal(true);
    place.exec();
}

void EspaceAdmin::on_pushButton_2_clicked()
{
    hide ();
    voiture v;
    v.setModal(true);
    v.exec();

}


