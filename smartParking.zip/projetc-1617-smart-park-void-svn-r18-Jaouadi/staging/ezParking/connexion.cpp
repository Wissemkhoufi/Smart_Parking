#include "connexion.h"

Connexion::Connexion()
{

}

bool Connexion::createConnexion()
{
     Connexion C;
     C.db = QSqlDatabase::addDatabase("QODBC");
     C.db.setDatabaseName("XE");
     C.db.setUserName("system");
     C.db.setPassword("system");
     return C.db.open();
}
