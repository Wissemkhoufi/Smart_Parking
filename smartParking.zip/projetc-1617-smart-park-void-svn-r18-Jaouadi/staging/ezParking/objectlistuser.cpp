#include "objectlistuser.h"
#include "ui_objectlistuser.h"
#include "espaceutilisateur.h"
ObjectListUser::ObjectListUser(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ObjectListUser)
{
    ui->setupUi(this);
}

ObjectListUser::~ObjectListUser()
{
    delete ui;
}

void ObjectListUser::on_OK_clicked()
{
    hide();
    EspaceUtilisateur espaceUser;
    espaceUser.setModal(true);
    espaceUser.exec();
}
