#ifndef UPDATEACCOUNTUSER_H
#define UPDATEACCOUNTUSER_H

#include <QDialog>

namespace Ui {
class UpdateAccountUser;
}

class UpdateAccountUser : public QDialog
{
    Q_OBJECT

public:
    explicit UpdateAccountUser(QWidget *parent = 0);
    ~UpdateAccountUser();

private slots:
    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    Ui::UpdateAccountUser *ui;
};

#endif // UPDATEACCOUNTUSER_H
