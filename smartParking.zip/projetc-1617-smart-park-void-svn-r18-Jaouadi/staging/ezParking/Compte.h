/**
 * \file      Compte.h
 * \author    Equipe Void
 * \version   1.0
 * \date      19/10/2016
 * \brief     Définit un compte d'utilisateur de l'application
 *
 */

#ifndef _COMPTE_H
#define _COMPTE_H
#include <QString>
#include <QSqlQuery>
#include <QtSql>
#include <QVariant>
/** \namespace std */
using namespace std;

class Compte {
protected:
    QString login;
    QString mdp;
    int type_compte;
public:
    void sAuthentifier();

    void modifierSonCompte();
    Compte (QString l ="", QString m ="", int t =0);

    bool ajouterUtilisateur();

    void modifierCompte();

    void supprimerCompte();
};

#endif //_COMPTE_H
