#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "authentificationadmin.h"
#include "authentificationuser.h"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_admin_clicked()
{
    hide();
    AuthentificationAdmin autAdmin;
    autAdmin.setModal(true);
    autAdmin.exec();
}

void MainWindow::on_utilisateur_clicked()
{
    hide();
    authentificationUser autUser;
    autUser.setModal(true);
    autUser.exec();
}
