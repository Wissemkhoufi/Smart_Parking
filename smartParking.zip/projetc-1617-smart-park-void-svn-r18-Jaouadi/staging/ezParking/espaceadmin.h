#ifndef ESPACEADMIN_H
#define ESPACEADMIN_H

#include <QDialog>

namespace Ui {
class EspaceAdmin;
}

class EspaceAdmin : public QDialog
{
    Q_OBJECT

public:
    explicit EspaceAdmin(QWidget *parent = 0);
    ~EspaceAdmin();

private slots:

    void on_updAcc_clicked();

    void on_addUser_clicked();

    void on_addObj_clicked();

    void on_updObj_clicked();

    void on_stat_clicked();

    void on_statePark_clicked();

   // void on_objectList_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::EspaceAdmin *ui;
};

#endif // ESPACEADMIN_H
