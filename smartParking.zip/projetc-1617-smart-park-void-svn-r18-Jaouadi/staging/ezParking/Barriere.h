/**
 * \file      Barriere.h
 * \author    Equipe Void
 * \version   1.0
 * \date      19/10/2016
 * \brief     gère la barriere
 *
 */

#ifndef _BARRIERE_H
#define _BARRIERE_H

#include "Objet.h"

/** \namespace std */
using namespace std;

class Barriere: public Objet {
public:

    void leverBarriere();

    void faireDescendreBarriere();
};

#endif //_BARRIERE_H
