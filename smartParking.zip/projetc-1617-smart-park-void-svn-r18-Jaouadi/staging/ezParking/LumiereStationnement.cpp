/**
 * Project Untitled
 */


#include "LumiereStationnement.h"

/**
 * LumiereStationnement implementation
 */


void LumiereStationnement::clignoter()
{

}
