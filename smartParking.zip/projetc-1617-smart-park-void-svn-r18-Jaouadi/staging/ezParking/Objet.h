/**
 * \file      Objet.h
 * \author    Equipe Void
 * \version   1.0
 * \date      19/10/2016
 * \brief     Définit le contôle des objets du parking
 *
 * \details    Cette classe contôle les objets du parking
 */


#ifndef _OBJET_H
#define _OBJET_H
#include <string>

/** \namespace std */
using namespace std;

class Objet {
protected:
    int identifiant;
    string dateAjout;
public:
    void controlerObjet();
};

#endif //_OBJET_H
