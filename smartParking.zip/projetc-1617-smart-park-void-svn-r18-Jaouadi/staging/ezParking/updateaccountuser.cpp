#include "updateaccountuser.h"
#include "ui_updateaccountuser.h"
#include "espaceutilisateur.h"
UpdateAccountUser::UpdateAccountUser(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UpdateAccountUser)
{
    ui->setupUi(this);
}

UpdateAccountUser::~UpdateAccountUser()
{
    delete ui;
}

void UpdateAccountUser::on_buttonBox_accepted()
{
    hide();
    EspaceUtilisateur espaceUser;
    espaceUser.setModal(true);
    espaceUser.exec();
}

void UpdateAccountUser::on_buttonBox_rejected()
{
    hide();
    EspaceUtilisateur espaceUser;
    espaceUser.setModal(true);
    espaceUser.exec();
}
