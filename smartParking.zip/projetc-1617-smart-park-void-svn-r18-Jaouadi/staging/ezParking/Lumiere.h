/**
 * \file      Lumiere.h
 * \author    Equipe Void
 * \version   1.0
 * \date      19/10/2016
 * \brief     gère les lumiere
 *
 */


#ifndef _LUMIERE_H
#define _LUMIERE_H

#include "Objet.h"

/** \namespace std */
using namespace std;

class Lumiere: public Objet {
public:

    void declencherLumiere();

    void eteindreLumiere();
};

#endif //_LUMIERE_H
