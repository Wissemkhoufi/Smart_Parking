#ifndef ADDOBJECT_H
#define ADDOBJECT_H

#include <QDialog>

namespace Ui {
class AddObject;
}

class AddObject : public QDialog
{
    Q_OBJECT

public:
    explicit AddObject(QWidget *parent = 0);
    ~AddObject();

private slots:


    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::AddObject *ui;
};

#endif // ADDOBJECT_H
