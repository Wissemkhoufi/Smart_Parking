#ifndef SUPPRIMERPLACE_H
#define SUPPRIMERPLACE_H

#include <QDialog>

namespace Ui {
class supprimerplace;
}

class supprimerplace : public QDialog
{
    Q_OBJECT

public:
    explicit supprimerplace(QWidget *parent = 0);
    ~supprimerplace();

private:
    Ui::supprimerplace *ui;
};

#endif // SUPPRIMERPLACE_H
