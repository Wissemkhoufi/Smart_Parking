#include "addobject.h"
#include "ui_addobject.h"
#include "espaceadmin.h"
#include "mainwindow.h"
#include "connexion.h"
#include <QSqlQueryModel>
#include <QMessageBox>
#include <QSqlQuery>
#include <QDebug>


AddObject::AddObject(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddObject)
{
    ui->setupUi(this);
}

AddObject::~AddObject()
{
    delete ui;
}



void AddObject::on_pushButton_clicked()
{
    Connexion cx;
    QSqlQuery* qry = new QSqlQuery(cx.db) ;
    QString T[500];
    qry->prepare("select num_place from places");
    qry->exec();
    int i=0,j,tm,a=0;

    while(qry->next())
    {
        T[i]=qry->value(0).toString();
        i++;
        tm=i;
    }
    for (j=0;j<=tm;j++)
{
        //qDebug()<<T[j];
        if (ui->identifiant->displayText() == T[j] )
        {
              a=1;
        }


}
    if (a==1)
    {
        QMessageBox ::information(this,tr("Existant!"),tr("le numero que vous avez saisi est déjà existant inserer un autre"));
    }
    else
    {
        QString num=  ui->identifiant->displayText();
        QString desc = ui->textEdit->toPlainText();
        qry->prepare("insert into places (num_place,etat,description_capteur) values ("+num+",0,\'"+desc+"\')");
        qry->exec();
        QMessageBox ::information(this,tr("Success!"),tr("Place ajoutée"));
    }
    a=0;
}

void AddObject::on_pushButton_2_clicked()
{
    hide();
    EspaceAdmin espaceAdmin;
    espaceAdmin.setModal(true);
    espaceAdmin.exec();
}
