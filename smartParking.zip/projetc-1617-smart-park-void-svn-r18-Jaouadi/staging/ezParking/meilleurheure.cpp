#include "Meilleurheure.h"
#include "ui_meilleurheure.h"

Meilleurheure::Meilleurheure(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Meilleurheure)
{
    ui->setupUi(this);
}

Meilleurheure::~Meilleurheure()
{
    delete ui;
}

