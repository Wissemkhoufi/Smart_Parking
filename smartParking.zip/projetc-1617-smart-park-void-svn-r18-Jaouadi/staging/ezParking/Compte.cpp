/**
 * \file      Compte.cpp
 * \author    Equipe Void
 * \version   1.0
 * \date      19/10/2016
 * \brief     Définit un compte d'utilisateur de l'application
 *
 */


#include "Compte.h"

/** \namespace std */
using namespace std;

/**
 * \brief  pour s'authentifier
 */
void Compte::sAuthentifier() {

}

/**
 * \brief  gère la modification de son propre compte
 */
void Compte::modifierSonCompte() {

}


Compte::Compte (QString l,QString m, int t) : login(l), mdp(m), type_compte(t)
{}

/**
 * \brief  pour ajouter un utilisateur
 */
bool Compte::ajouterUtilisateur()
{
    QSqlQuery query;
    query.prepare("insert into utilisateurs values (:login,:mdp,:type)");
    query.bindValue(":login",login);
    query.bindValue(":mdp",mdp);
    query.bindValue(":type",type_compte);
    return query.exec();
}

/**
 * \brief  pour modifier un compte
 */
void Compte::modifierCompte() {

}

/**
 * \brief  supprime un compte
 */
void Compte::supprimerCompte() {

}

