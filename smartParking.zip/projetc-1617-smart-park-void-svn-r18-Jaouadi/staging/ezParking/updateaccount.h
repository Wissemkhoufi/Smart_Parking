#ifndef UPDATEACCOUNT_H
#define UPDATEACCOUNT_H

#include <QDialog>

namespace Ui {
class UpdateAccount;
}

class UpdateAccount : public QDialog
{
    Q_OBJECT

public:
    explicit UpdateAccount(QWidget *parent = 0);
    ~UpdateAccount();

private slots:
    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    Ui::UpdateAccount *ui;
};

#endif // UPDATEACCOUNT_H
