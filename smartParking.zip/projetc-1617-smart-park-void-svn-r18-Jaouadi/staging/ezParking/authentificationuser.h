#ifndef AUTHENTIFICATIONUSER_H
#define AUTHENTIFICATIONUSER_H

#include <QDialog>

namespace Ui {
class authentificationUser;
}

class authentificationUser : public QDialog
{
    Q_OBJECT

public:
    explicit authentificationUser(QWidget *parent = 0);
    ~authentificationUser();

private slots:
    void on_buttonBox_rejected();

    void on_buttonBox_accepted();

private:
    Ui::authentificationUser *ui;
};

#endif // AUTHENTIFICATIONUSER_H
