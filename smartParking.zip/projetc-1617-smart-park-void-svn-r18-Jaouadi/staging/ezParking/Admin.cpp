/**
 * \file      Admin.cpp
 * \author    Equipe Void
 * \version   1.0
 * \date      19/10/2016
 * \brief     Définit les privilèges de l'admin
 *
 */

#include "Admin.h"

/** \namespace std */
using namespace std;


