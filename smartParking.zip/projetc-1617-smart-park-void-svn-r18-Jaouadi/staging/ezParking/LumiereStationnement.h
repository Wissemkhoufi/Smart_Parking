/**
 * \file      LumiereStationnement.h
 * \author    Equipe Void
 * \version   1.0
 * \date      19/10/2016
 * \brief     gère les lumiere de stationnement
 *
 */

#ifndef _LUMIERESTATIONNEMENT_H
#define _LUMIERESTATIONNEMENT_H

#include "Lumiere.h"


class LumiereStationnement: public Lumiere {
public:

    void clignoter();
};

#endif //_LUMIERESTATIONNEMENT_H
