#ifndef MEILLEURHEURE_H
#define MEILLEURHEURE_H

#include <QDialog>
#include "ui_meilleurheure.h"

namespace Ui {
class Meilleurheure;
}

class Meilleurheure : public QDialog
{
    Q_OBJECT

public:
    explicit Meilleurheure(QWidget *parent = 0);
    ~Meilleurheure();



private slots:
    //void on_pushButton_clicked();

    void on_Calc_clicked();

    void on_pushButton_clicked();

private:
    Ui::Meilleurheure *ui;
};

#endif // MEILLEURHEURE_H
