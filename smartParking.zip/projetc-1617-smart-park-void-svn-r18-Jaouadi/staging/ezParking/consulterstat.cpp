#include "consulterstat.h"
#include "ui_consulterstat.h"
#include "espaceadmin.h"
#include "espaceadmin.h"
#include "connexion.h"
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QSqlDatabase>
#include <QDebug>
#include <QMessageBox>
#include <QDateTime>

ConsulterStat::ConsulterStat(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ConsulterStat)
{
    ui->setupUi(this);
}

ConsulterStat::~ConsulterStat()
{
    delete ui;
}

void ConsulterStat::on_OK_clicked()
{
    hide();
    EspaceAdmin espaceAdmin;
    espaceAdmin.setModal(true);
    espaceAdmin.exec();
}

void ConsulterStat::on_pushButton_clicked()
{
    /*Connexion c;
    int i;
    QSqlQuery* qry = new QSqlQuery(c.db) ;
    qry->prepare("select date_entree from voiture");
    qry->exec();
    QDateTime dateTime = qry->value(0).toDateTime();*/

}
