#include "supprimerplace.h"
#include "ui_supprimerplace.h"

supprimerplace::supprimerplace(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::supprimerplace)
{
    ui->setupUi(this);
}

supprimerplace::~supprimerplace()
{
    delete ui;
}
