#include "updateaccount.h"
#include "ui_updateaccount.h"
#include "espaceadmin.h"
UpdateAccount::UpdateAccount(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UpdateAccount)
{
    ui->setupUi(this);
}

UpdateAccount::~UpdateAccount()
{
    delete ui;
}

void UpdateAccount::on_buttonBox_accepted()
{
    hide();
    EspaceAdmin espaceAdmin;
    espaceAdmin.setModal(true);
    espaceAdmin.exec();
}

void UpdateAccount::on_buttonBox_rejected()
{
    hide();
    EspaceAdmin espaceAdmin;
    espaceAdmin.setModal(true);
    espaceAdmin.exec();
}
