/**
 * \file      Objet.cpp
 * \author    Equipe Void
 * \version   1.0
 * \date      19/10/2016
 * \brief     Définit le contôle des objets du parking
 *
 * \details    Cette classe contôle les objets du parking
 */

#include "Objet.h"

/** \namespace std */
using namespace std;


/**
 * \brief  contrôle les objets du parking
 */
void Objet::controlerObjet()
{

}
