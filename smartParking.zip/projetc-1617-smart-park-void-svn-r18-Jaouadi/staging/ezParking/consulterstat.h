#ifndef CONSULTERSTAT_H
#define CONSULTERSTAT_H

#include <QDialog>

namespace Ui {
class ConsulterStat;
}

class ConsulterStat : public QDialog
{
    Q_OBJECT

public:
    explicit ConsulterStat(QWidget *parent = 0);
    ~ConsulterStat();

private slots:
    void on_OK_clicked();

    void on_pushButton_clicked();

private:
    Ui::ConsulterStat *ui;
};

#endif // CONSULTERSTAT_H
