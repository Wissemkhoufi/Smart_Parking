/**
 * Project Untitled
 */


#include "Diode.h"

/**
 * Diode implementation
 */


void Diode::indiquerChemin() {

}
