#ifndef UPDATEOBJECT_H
#define UPDATEOBJECT_H

#include <QDialog>

namespace Ui {
class UpdateObject;
}

class UpdateObject : public QDialog
{
    Q_OBJECT

public:
    explicit UpdateObject(QWidget *parent = 0);
    ~UpdateObject();

private slots:
    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

    void on_buttonBox_2_accepted();

    void on_pushButton_clicked();

private:
    Ui::UpdateObject *ui;
};

#endif // UPDATEOBJECT_H
