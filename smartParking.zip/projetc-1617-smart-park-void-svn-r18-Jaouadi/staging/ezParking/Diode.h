/**
 * \file      Diode.h
 * \author    Equipe Void
 * \version   1.0
 * \date      19/10/2016
 * \brief     gère les diodes de stationnement
 *
 */

#ifndef _DIODE_H
#define _DIODE_H

#include "Lumiere.h"

/** \namespace std */
using namespace std;

class Diode: public Lumiere {
public:

    void indiquerChemin();
};

#endif //_DIODE_H
