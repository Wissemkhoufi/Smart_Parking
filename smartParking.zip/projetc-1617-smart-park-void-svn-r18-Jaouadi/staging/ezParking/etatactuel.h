#ifndef ETATACTUEL_H
#define ETATACTUEL_H

#include <QDialog>

namespace Ui {
class EtatActuel;
}

class EtatActuel : public QDialog
{
    Q_OBJECT

public:
    explicit EtatActuel(QWidget *parent = 0);
    ~EtatActuel();

private slots:
    void on_OK_clicked();

    void on_pushButton_clicked();

private:
    Ui::EtatActuel *ui;
};

#endif // ETATACTUEL_H
