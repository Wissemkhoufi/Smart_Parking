#include "updateobject.h"
#include "ui_updateobject.h"
#include "espaceadmin.h"
#include "connexion.h"
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QSqlDatabase>
#include <QDebug>
#include <QMessageBox>

UpdateObject::UpdateObject(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UpdateObject)
{
    ui->setupUi(this);
}

UpdateObject::~UpdateObject()
{
    delete ui;
}

void UpdateObject::on_buttonBox_accepted()
{
    hide();
    EspaceAdmin espaceAdmin;
    espaceAdmin.setModal(true);
    espaceAdmin.exec();
}

void UpdateObject::on_buttonBox_rejected()
{
    hide();
    EspaceAdmin espaceAdmin;
    espaceAdmin.setModal(true);
    espaceAdmin.exec();
}


void UpdateObject::on_pushButton_clicked()
{
    Connexion c;
    QSqlQueryModel * modal = new QSqlQueryModel ();


    QSqlQuery* qry = new QSqlQuery(c.db) ;
    qry->prepare("select num_place from places");
    qry->exec();
    modal->setQuery(*qry);
    ui->objectList->setModel(modal);
    qDebug() <<(modal->rowCount() );
}
