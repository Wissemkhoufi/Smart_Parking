#include "Place.h"
#include "ui_Place.h"
#include "espaceadmin.h"
#include "connexion.h"
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QSqlDatabase>
#include <QDebug>
#include <QMessageBox>

Place::Place(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Place)
{
    ui->setupUi(this);
    //ui->listWidget->addItem("hello");
}

Place::~Place()
{
    delete ui;
}

void Place::on_pushButton_clicked()
{
    hide ();
    EspaceAdmin es;
    es.setModal(true);
    es.exec();
}


void Place::on_load_clicked()
{
    Connexion c;
    QSqlQueryModel * modal = new QSqlQueryModel ();


    QSqlQuery* qry = new QSqlQuery(c.db) ;
    qry->prepare("select num_place from places");
    qry->exec();
    modal->setQuery(*qry);
    ui->comboBox->setModel(modal);
    qDebug() <<(modal->rowCount() );
}

void Place::on_pushButton_2_clicked()
{
    QString id=ui->comboBox->currentText();
    QSqlQuery qry;

    int ControleRetValue = QMessageBox ::question(this,"suppression de place","vous êtes sure de supprimer cette place?",
                                                                                     QMessageBox::Yes|
                                                                                     QMessageBox::No |
                                                                                     QMessageBox::Cancel,
                                                                                     QMessageBox::Yes );
    switch (ControleRetValue) {
    case QMessageBox::Yes :
        qry.prepare("Delete from places where num_place='"+id+"'");
        qry.exec();
        QMessageBox ::information(this,tr("Supprimé"),tr("suppression terminé avec succé"));
        break;
    case QMessageBox::No :
       QMessageBox ::information(this,tr("Non supprimé"),tr("suppression annulé"));

        break;
    case QMessageBox::Cancel :
      QMessageBox ::information(this,tr("Canceled"),tr("operation annulé"));
        break;
    default :
        //QSqlQuery qry;
        qry.prepare("Delete from places where num_place='"+id+"'");
        qry.exec();
        QMessageBox ::information(this,tr("Supprimé"),tr("suppression terminé avec succé"));
        break;
    }
}
