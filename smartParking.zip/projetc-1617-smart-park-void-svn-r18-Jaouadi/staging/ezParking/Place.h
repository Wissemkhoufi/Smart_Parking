/**
 * \file      Place.h
 * \author    Equipe Void
 * \version   1.0
 * \date      19/10/2016
 * \brief     Définit la gestion des places du parking
 *
 * \details    Cette classe gère les places du parking
 */

#ifndef _PLACE_H
#define _PLACE_H

#include "Objet.h"

#include <QDialog>


/** \namespace std */
using namespace std;

namespace Ui {
class Place;
}

class Place : public QDialog,Objet
{
    Q_OBJECT
    int etat;
public:
    void ajouterPlace();

    void modifierPlace();

    //void supprimerPlace();

public:
    explicit Place(QWidget *parent = 0);
    ~Place();

private slots:
    void on_pushButton_clicked();

   // void on_pushButton_2_clicked();

    void on_load_clicked();

    //void on_comboBox_currentIndexChanged(const QString &arg1);

    void on_pushButton_2_clicked();

private:
    Ui::Place *ui;
};

#endif //_PLACE_H
