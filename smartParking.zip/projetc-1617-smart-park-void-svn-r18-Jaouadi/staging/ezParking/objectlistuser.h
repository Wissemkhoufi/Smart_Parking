#ifndef OBJECTLISTUSER_H
#define OBJECTLISTUSER_H

#include <QDialog>

namespace Ui {
class ObjectListUser;
}

class ObjectListUser : public QDialog
{
    Q_OBJECT

public:
    explicit ObjectListUser(QWidget *parent = 0);
    ~ObjectListUser();

private slots:
    void on_OK_clicked();

private:
    Ui::ObjectListUser *ui;
};

#endif // OBJECTLISTUSER_H
