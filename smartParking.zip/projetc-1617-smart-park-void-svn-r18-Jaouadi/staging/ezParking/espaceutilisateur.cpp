#include "espaceutilisateur.h"
#include "ui_espaceutilisateur.h"
#include "updateaccountuser.h"
#include "etatactuelutilisateur.h"
#include "objectlistuser.h"
EspaceUtilisateur::EspaceUtilisateur(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::EspaceUtilisateur)
{
    ui->setupUi(this);
}

EspaceUtilisateur::~EspaceUtilisateur()
{
    delete ui;
}

void EspaceUtilisateur::on_updateAcc_clicked()
{
    hide();
    UpdateAccountUser updUser;
    updUser.setModal(true);
    updUser.exec();
}

void EspaceUtilisateur::on_parkState_clicked()
{
    hide();
    EtatActuelUtilisateur etatActuel;
    etatActuel.setModal(true);
    etatActuel.exec();
}

void EspaceUtilisateur::on_objectList_clicked()
{
    hide();
    ObjectListUser objectList;
    objectList.setModal(true);
    objectList.exec();
}
