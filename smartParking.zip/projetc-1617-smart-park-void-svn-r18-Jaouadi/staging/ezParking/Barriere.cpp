/**
 * Project Untitled
 */


#include "Barriere.h"

/**
 * Barriere implementation
 */


void Barriere::leverBarriere() {

}

void Barriere::faireDescendreBarriere() {

}
