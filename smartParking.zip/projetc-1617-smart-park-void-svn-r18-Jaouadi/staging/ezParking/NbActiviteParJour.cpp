/**
 * \file      Nombre d'activité par jour.cpp
 * \author    Equipe Void
 * \version   1.0
 * \date      19/10/2016
 * \brief     Définit le nombre d'activité d'un objet par jour
 *
 */

#include "NbActiviteParJour.h"




