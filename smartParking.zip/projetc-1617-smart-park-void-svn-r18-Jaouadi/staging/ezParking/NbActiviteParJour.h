/**
 * \file      Nombre d'activité par jour.h
 * \author    Equipe Void
 * \version   1.0
 * \date      19/10/2016
 * \brief     Définit le nombre d'activité d'un objet par jour
 *
 */

#ifndef NBACTIVITEPARJOUR_H
#define NBACTIVITEPARJOUR_H
#include <QString>




/** \namespace std */
using namespace std;

class NbrActiviteParJour {
private:
    QString dateHeure;
    int nombreActivite;
};


#endif // NBACTIVITEPARJOUR_H
