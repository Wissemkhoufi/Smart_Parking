/**
 * \file      Admin.h
 * \author    Equipe Void
 * \version   1.0
 * \date      19/10/2016
 * \brief     Définit les privilèges de l'admin
 *
 */


#ifndef _ADMIN_H
#define _ADMIN_H

#include "Compte.h"


/** \namespace std */
using namespace std;


class Admin: public Compte {
public:


};

#endif //_ADMIN_H
