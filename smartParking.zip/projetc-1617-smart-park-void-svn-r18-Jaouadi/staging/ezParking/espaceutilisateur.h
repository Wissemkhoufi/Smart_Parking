#ifndef ESPACEUTILISATEUR_H
#define ESPACEUTILISATEUR_H

#include <QDialog>

namespace Ui {
class EspaceUtilisateur;
}

class EspaceUtilisateur : public QDialog
{
    Q_OBJECT

public:
    explicit EspaceUtilisateur(QWidget *parent = 0);
    ~EspaceUtilisateur();

private slots:
    void on_updateAcc_clicked();

    void on_parkState_clicked();

    void on_objectList_clicked();

private:
    Ui::EspaceUtilisateur *ui;
};

#endif // ESPACEUTILISATEUR_H

