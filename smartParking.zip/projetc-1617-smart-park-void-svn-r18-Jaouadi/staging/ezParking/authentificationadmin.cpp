#include "authentificationadmin.h"
#include "ui_authentificationadmin.h"
#include "espaceadmin.h"
#include "mainwindow.h"

AuthentificationAdmin::AuthentificationAdmin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AuthentificationAdmin)
{
    ui->setupUi(this);
}

AuthentificationAdmin::~AuthentificationAdmin()
{
    delete ui;
}

void AuthentificationAdmin::on_buttonBox_accepted()
{
    hide();
    EspaceAdmin espaceAdmin;
    espaceAdmin.setModal(true);
    espaceAdmin.exec();
}

void AuthentificationAdmin::on_buttonBox_rejected()
{
     hide();
     MainWindow *mainWindow = new MainWindow();
         mainWindow->show();
}
