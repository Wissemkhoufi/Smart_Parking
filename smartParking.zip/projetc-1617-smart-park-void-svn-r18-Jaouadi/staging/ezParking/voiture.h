#ifndef VOITURE_H
#define VOITURE_H

#include <QDialog>

namespace Ui {
class voiture;
}

class voiture : public QDialog
{
    Q_OBJECT

public:
    explicit voiture(QWidget *parent = 0);
    ~voiture();

private slots:
    void on_pushButton_clicked();
   // void charger_combo_box();

   // void on_voiture_accepted();

   // void on_placelibre_activated(const QString &arg1);

    void on_pushButton_2_clicked();

    //void on_dateTimeEdit_editingFinished();

    void on_pushButton_3_clicked();

private:
    Ui::voiture *ui;
};

#endif // VOITURE_H
