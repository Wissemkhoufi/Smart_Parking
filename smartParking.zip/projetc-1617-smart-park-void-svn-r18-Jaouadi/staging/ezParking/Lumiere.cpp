/**
 * Project Untitled
 */


#include "Lumiere.h"

/**
 * Lumiere implementation
 */


void Lumiere::declencherLumiere() {

}

void Lumiere::eteindreLumiere() {

}
