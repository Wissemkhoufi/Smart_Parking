#include "mainwindow.h"
#include <QApplication>
#include "connexion.h"
#include <QDebug>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    Connexion c;
    w.show();
    qDebug()<< c.createConnexion()<<"eee'e";
    return a.exec();
}
