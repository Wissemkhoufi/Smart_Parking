#include "etatactuel.h"
#include "ui_etatactuel.h"
#include "espaceadmin.h"
#include "connexion.h"
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QSqlDatabase>
#include <QDebug>
#include <QMessageBox>

EtatActuel::EtatActuel(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::EtatActuel)
{
    ui->setupUi(this);
}

EtatActuel::~EtatActuel()
{
    delete ui;
}

void EtatActuel::on_OK_clicked()
{
    hide();
    EspaceAdmin espaceAdmin;
    espaceAdmin.setModal(true);
    espaceAdmin.exec();
}

void EtatActuel::on_pushButton_clicked()
{
    Connexion c;
    QSqlQueryModel * modal = new QSqlQueryModel ();


    QSqlQuery* qry = new QSqlQuery(c.db) ;
    qry->prepare("select * from places");
    qry->exec();
    modal->setQuery(*qry);
    ui->tableView->setModel(modal);
    qDebug() <<(modal->rowCount() );
}
