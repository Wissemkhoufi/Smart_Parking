/**
 * \file      Statistiques.cpp
 * \author    Equipe Void
 * \version   1.0
 * \date      19/10/2016
 * \brief     Définit les différentes statistiques du parking
 *
 * \details    Cette classe calcule les différentes statistiques du parking.
 */


#include "Statistiques.h"

/** \namespace std */
using namespace std;

/**
 * \brief       Calcule le nombre de voiture par mois
 * \details    le nombre de voiture par mois est calculer en dévisant
               le nombre de voitures total d'un mois donnée dévisé
               par le nombre de jours de ce mois
 */

void Statistiques::nbrVoitureParMois() {

}
/**
 * \brief       Calcule la meilleure heure par jour et par mois
 */
void Statistiques::meilleureHeure() {

}

/**
 * \brief       Calcule la meilleur jour du mois
 */
void Statistiques::meilleurJour() {

}
