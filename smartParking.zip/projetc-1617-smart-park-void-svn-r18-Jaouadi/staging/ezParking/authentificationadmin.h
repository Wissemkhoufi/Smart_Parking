#ifndef AUTHENTIFICATIONADMIN_H
#define AUTHENTIFICATIONADMIN_H

#include <QDialog>

namespace Ui {
class AuthentificationAdmin;
}

class AuthentificationAdmin : public QDialog
{
    Q_OBJECT

public:
    explicit AuthentificationAdmin(QWidget *parent = 0);
    ~AuthentificationAdmin();

private slots:
    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    Ui::AuthentificationAdmin *ui;
};

#endif // AUTHENTIFICATIONADMIN_H
