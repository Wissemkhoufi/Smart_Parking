#ifndef ETATACTUELUTILISATEUR_H
#define ETATACTUELUTILISATEUR_H

#include <QDialog>

namespace Ui {
class EtatActuelUtilisateur;
}

class EtatActuelUtilisateur : public QDialog
{
    Q_OBJECT

public:
    explicit EtatActuelUtilisateur(QWidget *parent = 0);
    ~EtatActuelUtilisateur();

private slots:
    void on_OK_clicked();

private:
    Ui::EtatActuelUtilisateur *ui;
};

#endif // ETATACTUELUTILISATEUR_H
