#include "authentificationuser.h"
#include "ui_authentificationuser.h"
#include "mainwindow.h"
#include "espaceutilisateur.h"
authentificationUser::authentificationUser(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::authentificationUser)
{
    ui->setupUi(this);
}

authentificationUser::~authentificationUser()
{
    delete ui;
}

void authentificationUser::on_buttonBox_rejected()
{
    hide();
    MainWindow *mainWindow = new MainWindow();
        mainWindow->show();
}

void authentificationUser::on_buttonBox_accepted()
{
    hide();
    EspaceUtilisateur espaceUser;
    espaceUser.setModal(true);
    espaceUser.exec();
}
