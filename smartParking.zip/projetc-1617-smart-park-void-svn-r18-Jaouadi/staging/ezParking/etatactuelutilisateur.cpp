#include "etatactuelutilisateur.h"
#include "ui_etatactuelutilisateur.h"
#include "espaceutilisateur.h"
EtatActuelUtilisateur::EtatActuelUtilisateur(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::EtatActuelUtilisateur)
{
    ui->setupUi(this);
}

EtatActuelUtilisateur::~EtatActuelUtilisateur()
{
    delete ui;
}

void EtatActuelUtilisateur::on_OK_clicked()
{
    hide();
    EspaceUtilisateur espaceUser;
    espaceUser.setModal(true);
    espaceUser.exec();
}
