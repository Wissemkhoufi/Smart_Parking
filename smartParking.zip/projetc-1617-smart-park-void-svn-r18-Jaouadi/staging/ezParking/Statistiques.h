/**
 * \file      Statistiques.h
 * \author    Equipe Void
 * \version   1.0
 * \date      19/10/2016
 * \brief     Définit les différentes statistiques du parking
 *
 * \details    Cette classe calcule les différentes statistiques du parking.
 */

#ifndef _STATISTIQUES_H
#define _STATISTIQUES_H

/** \namespace std */
using namespace std;

class Statistiques {
public:

    void nbrVoitureParMois();

    void meilleureHeure();

    void meilleurJour();
};

#endif //_STATISTIQUES_H
