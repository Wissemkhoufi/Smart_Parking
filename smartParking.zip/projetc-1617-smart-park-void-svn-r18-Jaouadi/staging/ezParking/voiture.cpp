#include "voiture.h"
#include "ui_voiture.h"
#include "espaceadmin.h"
#include "connexion.h"
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QSqlDatabase>
#include <QDebug>
#include <QMessageBox>
#include <QDateTime>
#include <QDebug>

voiture::voiture(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::voiture)
{
    ui->setupUi(this);
}

voiture::~voiture()
{
    delete ui;
}

void voiture::on_pushButton_2_clicked()
{
    Connexion c;
    QSqlQueryModel * modal = new QSqlQueryModel ();


    QSqlQuery* qry = new QSqlQuery(c.db) ;
    qry->prepare("select num_place from places where (etat=0)");
    qry->exec();
    modal->setQuery(*qry);
    ui->placelibre->setModel(modal);
    qDebug() <<(modal->rowCount() );
}

void voiture::on_pushButton_clicked()
{
    Connexion c;
    QSqlQuery* qry = new QSqlQuery(c.db) ;
    qry->prepare("insert into voiture (date_entree) values (CURRENT_TIMESTAMP)");
    QString a = ui->placelibre->currentText();
    if (qry->exec())
    {
        qDebug() <<"inserted";
    }
    else
    {
        qDebug() <<"no";
    }
    qry->prepare("update places set etat=1 where(num_place = "+a+")");
    if (qry->exec())
    {
        qDebug() <<"inserted";
    }
    else
    {
        qDebug() <<"no";
    }
    QSqlQueryModel * modal = new QSqlQueryModel ();
    qry->prepare("select num_place from places where (etat=0)");
    qry->exec();
    modal->setQuery(*qry);
    ui->placelibre->setModel(modal);



}


void voiture::on_pushButton_3_clicked()
{
    hide ();
    EspaceAdmin es;
    es.setModal(true);
    es.exec();
}
