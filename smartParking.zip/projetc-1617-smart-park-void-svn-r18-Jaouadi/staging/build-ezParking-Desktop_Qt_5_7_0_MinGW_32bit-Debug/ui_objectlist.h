/********************************************************************************
** Form generated from reading UI file 'objectlist.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OBJECTLIST_H
#define UI_OBJECTLIST_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_ObjectList
{
public:
    QLabel *title;
    QPushButton *OK;
    QLabel *image;
    QPushButton *pushButton;
    QDateEdit *dateEdit;
    QLabel *label;

    void setupUi(QDialog *ObjectList)
    {
        if (ObjectList->objectName().isEmpty())
            ObjectList->setObjectName(QStringLiteral("ObjectList"));
        ObjectList->resize(800, 500);
        title = new QLabel(ObjectList);
        title->setObjectName(QStringLiteral("title"));
        title->setGeometry(QRect(310, -30, 391, 151));
        OK = new QPushButton(ObjectList);
        OK->setObjectName(QStringLiteral("OK"));
        OK->setGeometry(QRect(642, 440, 111, 28));
        image = new QLabel(ObjectList);
        image->setObjectName(QStringLiteral("image"));
        image->setGeometry(QRect(20, 110, 311, 271));
        image->setPixmap(QPixmap(QString::fromUtf8("../template graphique/images/logo 1.png")));
        pushButton = new QPushButton(ObjectList);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(350, 210, 161, 41));
        dateEdit = new QDateEdit(ObjectList);
        dateEdit->setObjectName(QStringLiteral("dateEdit"));
        dateEdit->setGeometry(QRect(350, 140, 161, 31));
        label = new QLabel(ObjectList);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(180, 140, 141, 31));
        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);

        retranslateUi(ObjectList);

        QMetaObject::connectSlotsByName(ObjectList);
    } // setupUi

    void retranslateUi(QDialog *ObjectList)
    {
        ObjectList->setWindowTitle(QApplication::translate("ObjectList", "Liste des objets", 0));
        title->setText(QApplication::translate("ObjectList", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#55aaff;\">Calculer Meilleure heure</span></p></body></html>", 0));
        OK->setText(QApplication::translate("ObjectList", "Retour", 0));
        image->setText(QString());
        pushButton->setText(QApplication::translate("ObjectList", "Ok", 0));
        label->setText(QApplication::translate("ObjectList", "<html><head/><body><p><span style=\" font-size:12pt; color:#33389e;\">Entrer la date</span></p></body></html>", 0));
    } // retranslateUi

};

namespace Ui {
    class ObjectList: public Ui_ObjectList {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OBJECTLIST_H
