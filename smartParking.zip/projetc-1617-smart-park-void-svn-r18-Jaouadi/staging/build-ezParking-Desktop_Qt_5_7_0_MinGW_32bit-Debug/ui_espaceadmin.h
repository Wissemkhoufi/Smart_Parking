/********************************************************************************
** Form generated from reading UI file 'espaceadmin.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ESPACEADMIN_H
#define UI_ESPACEADMIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_EspaceAdmin
{
public:
    QPushButton *updObj;
    QPushButton *updAcc;
    QLabel *authuser;
    QPushButton *addUser;
    QPushButton *statePark;
    QPushButton *stat;
    QPushButton *addObj;
    QLabel *image;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *EspaceAdmin)
    {
        if (EspaceAdmin->objectName().isEmpty())
            EspaceAdmin->setObjectName(QStringLiteral("EspaceAdmin"));
        EspaceAdmin->resize(800, 500);
        updObj = new QPushButton(EspaceAdmin);
        updObj->setObjectName(QStringLiteral("updObj"));
        updObj->setGeometry(QRect(500, 270, 181, 41));
        updAcc = new QPushButton(EspaceAdmin);
        updAcc->setObjectName(QStringLiteral("updAcc"));
        updAcc->setGeometry(QRect(500, 90, 181, 41));
        authuser = new QLabel(EspaceAdmin);
        authuser->setObjectName(QStringLiteral("authuser"));
        authuser->setGeometry(QRect(210, -70, 481, 181));
        addUser = new QPushButton(EspaceAdmin);
        addUser->setObjectName(QStringLiteral("addUser"));
        addUser->setGeometry(QRect(500, 30, 181, 41));
        statePark = new QPushButton(EspaceAdmin);
        statePark->setObjectName(QStringLiteral("statePark"));
        statePark->setGeometry(QRect(500, 450, 181, 41));
        stat = new QPushButton(EspaceAdmin);
        stat->setObjectName(QStringLiteral("stat"));
        stat->setGeometry(QRect(500, 390, 181, 41));
        addObj = new QPushButton(EspaceAdmin);
        addObj->setObjectName(QStringLiteral("addObj"));
        addObj->setGeometry(QRect(500, 210, 181, 41));
        image = new QLabel(EspaceAdmin);
        image->setObjectName(QStringLiteral("image"));
        image->setGeometry(QRect(60, 120, 321, 271));
        image->setPixmap(QPixmap(QString::fromUtf8("../template graphique/images/logo 1.png")));
        pushButton = new QPushButton(EspaceAdmin);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(500, 330, 181, 41));
        pushButton_2 = new QPushButton(EspaceAdmin);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(500, 150, 181, 41));

        retranslateUi(EspaceAdmin);

        QMetaObject::connectSlotsByName(EspaceAdmin);
    } // setupUi

    void retranslateUi(QDialog *EspaceAdmin)
    {
        EspaceAdmin->setWindowTitle(QApplication::translate("EspaceAdmin", "Dialog", 0));
        updObj->setText(QApplication::translate("EspaceAdmin", "Modifier une place", 0));
        updAcc->setText(QApplication::translate("EspaceAdmin", "Modifier un compte", 0));
        authuser->setText(QApplication::translate("EspaceAdmin", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#55aaff;\">Espace Admin</span></p></body></html>", 0));
        addUser->setText(QApplication::translate("EspaceAdmin", "Ajouter un utilisateur", 0));
        statePark->setText(QApplication::translate("EspaceAdmin", "Voir l'\303\251tat actuel du parking", 0));
        stat->setText(QApplication::translate("EspaceAdmin", "Consulter les statistiques", 0));
        addObj->setText(QApplication::translate("EspaceAdmin", "Ajouter une place", 0));
        image->setText(QString());
        pushButton->setText(QApplication::translate("EspaceAdmin", "Supprimer une place", 0));
        pushButton_2->setText(QApplication::translate("EspaceAdmin", "Ajouter Voiture", 0));
    } // retranslateUi

};

namespace Ui {
    class EspaceAdmin: public Ui_EspaceAdmin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ESPACEADMIN_H
