/********************************************************************************
** Form generated from reading UI file 'authentificationuser.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AUTHENTIFICATIONUSER_H
#define UI_AUTHENTIFICATIONUSER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>

QT_BEGIN_NAMESPACE

class Ui_authentificationUser
{
public:
    QDialogButtonBox *buttonBox;
    QLineEdit *passBox;
    QLineEdit *loginBox;
    QLabel *image;
    QLabel *password;
    QLabel *login;
    QLabel *authuser;

    void setupUi(QDialog *authentificationUser)
    {
        if (authentificationUser->objectName().isEmpty())
            authentificationUser->setObjectName(QStringLiteral("authentificationUser"));
        authentificationUser->resize(800, 500);
        buttonBox = new QDialogButtonBox(authentificationUser);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(430, 450, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        passBox = new QLineEdit(authentificationUser);
        passBox->setObjectName(QStringLiteral("passBox"));
        passBox->setGeometry(QRect(590, 250, 113, 22));
        passBox->setEchoMode(QLineEdit::Password);
        loginBox = new QLineEdit(authentificationUser);
        loginBox->setObjectName(QStringLiteral("loginBox"));
        loginBox->setGeometry(QRect(590, 200, 113, 22));
        image = new QLabel(authentificationUser);
        image->setObjectName(QStringLiteral("image"));
        image->setGeometry(QRect(60, 110, 311, 271));
        image->setPixmap(QPixmap(QString::fromUtf8("../template graphique/images/logo 1.png")));
        password = new QLabel(authentificationUser);
        password->setObjectName(QStringLiteral("password"));
        password->setGeometry(QRect(450, 240, 121, 51));
        login = new QLabel(authentificationUser);
        login->setObjectName(QStringLiteral("login"));
        login->setGeometry(QRect(450, 180, 71, 51));
        authuser = new QLabel(authentificationUser);
        authuser->setObjectName(QStringLiteral("authuser"));
        authuser->setGeometry(QRect(210, -40, 481, 181));

        retranslateUi(authentificationUser);
        QObject::connect(buttonBox, SIGNAL(accepted()), authentificationUser, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), authentificationUser, SLOT(reject()));

        QMetaObject::connectSlotsByName(authentificationUser);
    } // setupUi

    void retranslateUi(QDialog *authentificationUser)
    {
        authentificationUser->setWindowTitle(QApplication::translate("authentificationUser", "Authentification Utilisateur", 0));
        image->setText(QString());
        password->setText(QApplication::translate("authentificationUser", "<html><head/><body><p><span style=\" font-size:12pt;\">Mot de passe</span></p></body></html>", 0));
        login->setText(QApplication::translate("authentificationUser", "<html><head/><body><p><span style=\" font-size:12pt;\">Login</span></p></body></html>", 0));
        authuser->setText(QApplication::translate("authentificationUser", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#55aaff;\">Authentification Utilisateur</span></p></body></html>", 0));
    } // retranslateUi

};

namespace Ui {
    class authentificationUser: public Ui_authentificationUser {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AUTHENTIFICATIONUSER_H
