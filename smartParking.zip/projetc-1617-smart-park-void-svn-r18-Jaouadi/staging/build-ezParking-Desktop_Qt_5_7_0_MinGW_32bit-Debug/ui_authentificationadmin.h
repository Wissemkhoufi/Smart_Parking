/********************************************************************************
** Form generated from reading UI file 'authentificationadmin.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AUTHENTIFICATIONADMIN_H
#define UI_AUTHENTIFICATIONADMIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>

QT_BEGIN_NAMESPACE

class Ui_AuthentificationAdmin
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *title;
    QLabel *image;
    QLabel *login;
    QLabel *pass;
    QLineEdit *loginBox;
    QLineEdit *passBox;

    void setupUi(QDialog *AuthentificationAdmin)
    {
        if (AuthentificationAdmin->objectName().isEmpty())
            AuthentificationAdmin->setObjectName(QStringLiteral("AuthentificationAdmin"));
        AuthentificationAdmin->resize(800, 500);
        buttonBox = new QDialogButtonBox(AuthentificationAdmin);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(430, 440, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        title = new QLabel(AuthentificationAdmin);
        title->setObjectName(QStringLiteral("title"));
        title->setGeometry(QRect(240, -20, 391, 151));
        image = new QLabel(AuthentificationAdmin);
        image->setObjectName(QStringLiteral("image"));
        image->setGeometry(QRect(50, 110, 311, 271));
        image->setPixmap(QPixmap(QString::fromUtf8("../template graphique/images/logo 1.png")));
        login = new QLabel(AuthentificationAdmin);
        login->setObjectName(QStringLiteral("login"));
        login->setGeometry(QRect(450, 180, 71, 51));
        pass = new QLabel(AuthentificationAdmin);
        pass->setObjectName(QStringLiteral("pass"));
        pass->setGeometry(QRect(450, 250, 121, 51));
        loginBox = new QLineEdit(AuthentificationAdmin);
        loginBox->setObjectName(QStringLiteral("loginBox"));
        loginBox->setGeometry(QRect(580, 200, 113, 22));
        passBox = new QLineEdit(AuthentificationAdmin);
        passBox->setObjectName(QStringLiteral("passBox"));
        passBox->setGeometry(QRect(580, 250, 113, 22));
        passBox->setEchoMode(QLineEdit::Password);

        retranslateUi(AuthentificationAdmin);
        QObject::connect(buttonBox, SIGNAL(accepted()), AuthentificationAdmin, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), AuthentificationAdmin, SLOT(reject()));

        QMetaObject::connectSlotsByName(AuthentificationAdmin);
    } // setupUi

    void retranslateUi(QDialog *AuthentificationAdmin)
    {
        AuthentificationAdmin->setWindowTitle(QApplication::translate("AuthentificationAdmin", "Authentification Admin", 0));
        title->setText(QApplication::translate("AuthentificationAdmin", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#55aaff;\">Authentification Admin</span></p></body></html>", 0));
        image->setText(QString());
        login->setText(QApplication::translate("AuthentificationAdmin", "<html><head/><body><p><span style=\" font-size:12pt;\">Login</span></p></body></html>", 0));
        pass->setText(QApplication::translate("AuthentificationAdmin", "<html><head/><body><p><span style=\" font-size:12pt;\">Mot de passe</span></p><p><br/></p></body></html>", 0));
    } // retranslateUi

};

namespace Ui {
    class AuthentificationAdmin: public Ui_AuthentificationAdmin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AUTHENTIFICATIONADMIN_H
