/********************************************************************************
** Form generated from reading UI file 'objectlistuser.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OBJECTLISTUSER_H
#define UI_OBJECTLISTUSER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_ObjectListUser
{
public:
    QLabel *image;
    QPushButton *OK;
    QLabel *title;

    void setupUi(QDialog *ObjectListUser)
    {
        if (ObjectListUser->objectName().isEmpty())
            ObjectListUser->setObjectName(QStringLiteral("ObjectListUser"));
        ObjectListUser->resize(800, 500);
        image = new QLabel(ObjectListUser);
        image->setObjectName(QStringLiteral("image"));
        image->setGeometry(QRect(20, 120, 311, 271));
        image->setPixmap(QPixmap(QString::fromUtf8("../template graphique/images/logo 1.png")));
        OK = new QPushButton(ObjectListUser);
        OK->setObjectName(QStringLiteral("OK"));
        OK->setGeometry(QRect(662, 460, 111, 28));
        title = new QLabel(ObjectListUser);
        title->setObjectName(QStringLiteral("title"));
        title->setGeometry(QRect(280, -40, 391, 151));

        retranslateUi(ObjectListUser);

        QMetaObject::connectSlotsByName(ObjectListUser);
    } // setupUi

    void retranslateUi(QDialog *ObjectListUser)
    {
        ObjectListUser->setWindowTitle(QApplication::translate("ObjectListUser", "Liste des objets", 0));
        image->setText(QString());
        OK->setText(QApplication::translate("ObjectListUser", "OK", 0));
        title->setText(QApplication::translate("ObjectListUser", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#55aaff;\">Liste ds objets</span></p></body></html>", 0));
    } // retranslateUi

};

namespace Ui {
    class ObjectListUser: public Ui_ObjectListUser {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OBJECTLISTUSER_H
