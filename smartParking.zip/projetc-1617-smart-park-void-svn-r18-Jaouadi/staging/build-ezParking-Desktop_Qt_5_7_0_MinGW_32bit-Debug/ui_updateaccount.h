/********************************************************************************
** Form generated from reading UI file 'updateaccount.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_UPDATEACCOUNT_H
#define UI_UPDATEACCOUNT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_UpdateAccount
{
public:
    QLabel *decsription;
    QLabel *dateAjout;
    QLineEdit *idBox;
    QComboBox *objectList;
    QTextEdit *descBox;
    QLabel *identifiant;
    QLineEdit *nameBox;
    QLabel *reference;
    QLineEdit *refBox;
    QLabel *selectObject;
    QLabel *title;
    QDialogButtonBox *buttonBox;
    QLineEdit *dateBox;
    QLabel *nom;

    void setupUi(QDialog *UpdateAccount)
    {
        if (UpdateAccount->objectName().isEmpty())
            UpdateAccount->setObjectName(QStringLiteral("UpdateAccount"));
        UpdateAccount->resize(800, 500);
        decsription = new QLabel(UpdateAccount);
        decsription->setObjectName(QStringLiteral("decsription"));
        decsription->setGeometry(QRect(330, 320, 251, 51));
        dateAjout = new QLabel(UpdateAccount);
        dateAjout->setObjectName(QStringLiteral("dateAjout"));
        dateAjout->setGeometry(QRect(330, 280, 251, 51));
        idBox = new QLineEdit(UpdateAccount);
        idBox->setObjectName(QStringLiteral("idBox"));
        idBox->setGeometry(QRect(590, 160, 113, 22));
        objectList = new QComboBox(UpdateAccount);
        objectList->setObjectName(QStringLiteral("objectList"));
        objectList->setGeometry(QRect(590, 110, 111, 22));
        descBox = new QTextEdit(UpdateAccount);
        descBox->setObjectName(QStringLiteral("descBox"));
        descBox->setGeometry(QRect(470, 330, 241, 101));
        identifiant = new QLabel(UpdateAccount);
        identifiant->setObjectName(QStringLiteral("identifiant"));
        identifiant->setGeometry(QRect(330, 140, 251, 51));
        nameBox = new QLineEdit(UpdateAccount);
        nameBox->setObjectName(QStringLiteral("nameBox"));
        nameBox->setGeometry(QRect(590, 200, 113, 22));
        nameBox->setEchoMode(QLineEdit::Normal);
        reference = new QLabel(UpdateAccount);
        reference->setObjectName(QStringLiteral("reference"));
        reference->setGeometry(QRect(330, 240, 251, 51));
        refBox = new QLineEdit(UpdateAccount);
        refBox->setObjectName(QStringLiteral("refBox"));
        refBox->setGeometry(QRect(590, 250, 113, 22));
        refBox->setEchoMode(QLineEdit::Normal);
        selectObject = new QLabel(UpdateAccount);
        selectObject->setObjectName(QStringLiteral("selectObject"));
        selectObject->setGeometry(QRect(330, 90, 251, 51));
        title = new QLabel(UpdateAccount);
        title->setObjectName(QStringLiteral("title"));
        title->setGeometry(QRect(210, -50, 391, 151));
        buttonBox = new QDialogButtonBox(UpdateAccount);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(390, 450, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        dateBox = new QLineEdit(UpdateAccount);
        dateBox->setObjectName(QStringLiteral("dateBox"));
        dateBox->setGeometry(QRect(590, 290, 113, 22));
        dateBox->setEchoMode(QLineEdit::Normal);
        nom = new QLabel(UpdateAccount);
        nom->setObjectName(QStringLiteral("nom"));
        nom->setGeometry(QRect(330, 190, 211, 51));

        retranslateUi(UpdateAccount);

        QMetaObject::connectSlotsByName(UpdateAccount);
    } // setupUi

    void retranslateUi(QDialog *UpdateAccount)
    {
        UpdateAccount->setWindowTitle(QApplication::translate("UpdateAccount", "Dialog", 0));
        decsription->setText(QApplication::translate("UpdateAccount", "<html><head/><body><p><span style=\" font-size:12pt;\">D\303\251scription</span></p></body></html>", 0));
        dateAjout->setText(QApplication::translate("UpdateAccount", "<html><head/><body><p><span style=\" font-size:12pt;\">Date d'ajout</span></p></body></html>", 0));
        identifiant->setText(QApplication::translate("UpdateAccount", "<html><head/><body><p><span style=\" font-size:12pt;\">Identifiant</span></p></body></html>", 0));
        reference->setText(QApplication::translate("UpdateAccount", "<html><head/><body><p><span style=\" font-size:12pt;\">R\303\251ference</span></p></body></html>", 0));
        selectObject->setText(QApplication::translate("UpdateAccount", "<html><head/><body><p><span style=\" font-size:12pt;\">S\303\251lectionner l'objet</span></p></body></html>", 0));
        title->setText(QApplication::translate("UpdateAccount", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#55aaff;\">Modifier un objet</span></p></body></html>", 0));
        nom->setText(QApplication::translate("UpdateAccount", "<html><head/><body><p><span style=\" font-size:12pt;\">Nom</span></p></body></html>", 0));
    } // retranslateUi

};

namespace Ui {
    class UpdateAccount: public Ui_UpdateAccount {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UPDATEACCOUNT_H
