/********************************************************************************
** Form generated from reading UI file 'meilleurheure.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MEILLEURHEURE_H
#define UI_MEILLEURHEURE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_Meilleurheure
{
public:
    QPushButton *pushButton;
    QTextEdit *textEdit;

    void setupUi(QDialog *Meilleurheure)
    {
        if (Meilleurheure->objectName().isEmpty())
            Meilleurheure->setObjectName(QStringLiteral("Meilleurheure"));
        Meilleurheure->resize(720, 364);
        pushButton = new QPushButton(Meilleurheure);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(124, 180, 201, 51));
        textEdit = new QTextEdit(Meilleurheure);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(123, 60, 201, 91));

        retranslateUi(Meilleurheure);

        QMetaObject::connectSlotsByName(Meilleurheure);
    } // setupUi

    void retranslateUi(QDialog *Meilleurheure)
    {
        Meilleurheure->setWindowTitle(QApplication::translate("Meilleurheure", "Dialog", 0));
        pushButton->setText(QApplication::translate("Meilleurheure", "calculer meilleure heure", 0));
    } // retranslateUi

};

namespace Ui {
    class Meilleurheure: public Ui_Meilleurheure {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MEILLEURHEURE_H
