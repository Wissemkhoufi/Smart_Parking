/********************************************************************************
** Form generated from reading UI file 'adduser.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDUSER_H
#define UI_ADDUSER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_AddUser
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *image;
    QLabel *login;
    QLineEdit *pass;
    QLineEdit *login_2;
    QLabel *password;
    QLabel *password_2;
    QLineEdit *pass2;
    QLabel *title;
    QRadioButton *boutonAdmin;
    QRadioButton *boutonUser;

    void setupUi(QDialog *AddUser)
    {
        if (AddUser->objectName().isEmpty())
            AddUser->setObjectName(QStringLiteral("AddUser"));
        AddUser->resize(800, 500);
        buttonBox = new QDialogButtonBox(AddUser);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(440, 450, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        image = new QLabel(AddUser);
        image->setObjectName(QStringLiteral("image"));
        image->setGeometry(QRect(40, 130, 311, 271));
        image->setPixmap(QPixmap(QString::fromUtf8("../template graphique/images/logo 1.png")));
        login = new QLabel(AddUser);
        login->setObjectName(QStringLiteral("login"));
        login->setGeometry(QRect(400, 130, 131, 51));
        pass = new QLineEdit(AddUser);
        pass->setObjectName(QStringLiteral("pass"));
        pass->setGeometry(QRect(660, 200, 113, 22));
        pass->setEchoMode(QLineEdit::Normal);
        login_2 = new QLineEdit(AddUser);
        login_2->setObjectName(QStringLiteral("login_2"));
        login_2->setGeometry(QRect(660, 150, 113, 22));
        password = new QLabel(AddUser);
        password->setObjectName(QStringLiteral("password"));
        password->setGeometry(QRect(400, 190, 211, 51));
        password_2 = new QLabel(AddUser);
        password_2->setObjectName(QStringLiteral("password_2"));
        password_2->setGeometry(QRect(400, 250, 251, 51));
        pass2 = new QLineEdit(AddUser);
        pass2->setObjectName(QStringLiteral("pass2"));
        pass2->setGeometry(QRect(660, 260, 113, 22));
        pass2->setEchoMode(QLineEdit::Normal);
        title = new QLabel(AddUser);
        title->setObjectName(QStringLiteral("title"));
        title->setGeometry(QRect(230, -20, 391, 151));
        boutonAdmin = new QRadioButton(AddUser);
        boutonAdmin->setObjectName(QStringLiteral("boutonAdmin"));
        boutonAdmin->setGeometry(QRect(440, 350, 95, 20));
        boutonUser = new QRadioButton(AddUser);
        boutonUser->setObjectName(QStringLiteral("boutonUser"));
        boutonUser->setGeometry(QRect(610, 350, 131, 20));

        retranslateUi(AddUser);
        QObject::connect(buttonBox, SIGNAL(accepted()), AddUser, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), AddUser, SLOT(reject()));

        QMetaObject::connectSlotsByName(AddUser);
    } // setupUi

    void retranslateUi(QDialog *AddUser)
    {
        AddUser->setWindowTitle(QApplication::translate("AddUser", "Ajouter un utilisateur", 0));
        image->setText(QString());
        login->setText(QApplication::translate("AddUser", "<html><head/><body><p><span style=\" font-size:12pt;\">Saisir le login</span></p></body></html>", 0));
        password->setText(QApplication::translate("AddUser", "<html><head/><body><p><span style=\" font-size:12pt;\">Saisir le mot de passe</span></p></body></html>", 0));
        password_2->setText(QApplication::translate("AddUser", "<html><head/><body><p><span style=\" font-size:12pt;\">Confirmer le mot de passe</span></p></body></html>", 0));
        title->setText(QApplication::translate("AddUser", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#55aaff;\">Ajouter un utilisateur</span></p></body></html>", 0));
        boutonAdmin->setText(QApplication::translate("AddUser", "Admin", 0));
        boutonUser->setText(QApplication::translate("AddUser", "Simple utilisateur", 0));
    } // retranslateUi

};

namespace Ui {
    class AddUser: public Ui_AddUser {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDUSER_H
