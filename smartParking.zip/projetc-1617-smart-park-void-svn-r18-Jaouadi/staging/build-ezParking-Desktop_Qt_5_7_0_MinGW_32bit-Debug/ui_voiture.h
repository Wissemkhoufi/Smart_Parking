/********************************************************************************
** Form generated from reading UI file 'voiture.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VOITURE_H
#define UI_VOITURE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_voiture
{
public:
    QComboBox *placelibre;
    QLabel *label;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;

    void setupUi(QDialog *voiture)
    {
        if (voiture->objectName().isEmpty())
            voiture->setObjectName(QStringLiteral("voiture"));
        voiture->resize(755, 429);
        placelibre = new QComboBox(voiture);
        placelibre->setObjectName(QStringLiteral("placelibre"));
        placelibre->setGeometry(QRect(440, 90, 191, 31));
        label = new QLabel(voiture);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(250, 100, 181, 20));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        pushButton = new QPushButton(voiture);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(550, 170, 171, 41));
        pushButton_2 = new QPushButton(voiture);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(650, 90, 61, 31));
        pushButton_3 = new QPushButton(voiture);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(570, 370, 141, 41));

        retranslateUi(voiture);

        QMetaObject::connectSlotsByName(voiture);
    } // setupUi

    void retranslateUi(QDialog *voiture)
    {
        voiture->setWindowTitle(QApplication::translate("voiture", "Dialog", 0));
        label->setText(QApplication::translate("voiture", "Choisissez le num de place", 0));
        pushButton->setText(QApplication::translate("voiture", "Ajouter voiture", 0));
        pushButton_2->setText(QApplication::translate("voiture", "Load", 0));
        pushButton_3->setText(QApplication::translate("voiture", "retour", 0));
    } // retranslateUi

};

namespace Ui {
    class voiture: public Ui_voiture {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VOITURE_H
