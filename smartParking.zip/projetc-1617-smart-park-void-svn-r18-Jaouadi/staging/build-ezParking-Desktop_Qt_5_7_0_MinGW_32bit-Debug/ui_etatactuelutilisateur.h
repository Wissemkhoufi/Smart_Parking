/********************************************************************************
** Form generated from reading UI file 'etatactuelutilisateur.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ETATACTUELUTILISATEUR_H
#define UI_ETATACTUELUTILISATEUR_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_EtatActuelUtilisateur
{
public:
    QPushButton *OK;
    QLabel *image;
    QLabel *title;

    void setupUi(QDialog *EtatActuelUtilisateur)
    {
        if (EtatActuelUtilisateur->objectName().isEmpty())
            EtatActuelUtilisateur->setObjectName(QStringLiteral("EtatActuelUtilisateur"));
        EtatActuelUtilisateur->resize(800, 500);
        OK = new QPushButton(EtatActuelUtilisateur);
        OK->setObjectName(QStringLiteral("OK"));
        OK->setGeometry(QRect(642, 440, 111, 28));
        image = new QLabel(EtatActuelUtilisateur);
        image->setObjectName(QStringLiteral("image"));
        image->setGeometry(QRect(20, 110, 311, 271));
        image->setPixmap(QPixmap(QString::fromUtf8("../template graphique/images/logo 1.png")));
        title = new QLabel(EtatActuelUtilisateur);
        title->setObjectName(QStringLiteral("title"));
        title->setGeometry(QRect(260, -40, 391, 151));

        retranslateUi(EtatActuelUtilisateur);

        QMetaObject::connectSlotsByName(EtatActuelUtilisateur);
    } // setupUi

    void retranslateUi(QDialog *EtatActuelUtilisateur)
    {
        EtatActuelUtilisateur->setWindowTitle(QApplication::translate("EtatActuelUtilisateur", "Etat actuel du parking", 0));
        OK->setText(QApplication::translate("EtatActuelUtilisateur", "OK", 0));
        image->setText(QString());
        title->setText(QApplication::translate("EtatActuelUtilisateur", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#55aaff;\">Etat actuel du parking</span></p></body></html>", 0));
    } // retranslateUi

};

namespace Ui {
    class EtatActuelUtilisateur: public Ui_EtatActuelUtilisateur {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ETATACTUELUTILISATEUR_H
