/********************************************************************************
** Form generated from reading UI file 'consulterstat.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONSULTERSTAT_H
#define UI_CONSULTERSTAT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_ConsulterStat
{
public:
    QLabel *image;
    QLabel *title;
    QPushButton *OK;

    void setupUi(QDialog *ConsulterStat)
    {
        if (ConsulterStat->objectName().isEmpty())
            ConsulterStat->setObjectName(QStringLiteral("ConsulterStat"));
        ConsulterStat->resize(800, 500);
        image = new QLabel(ConsulterStat);
        image->setObjectName(QStringLiteral("image"));
        image->setGeometry(QRect(30, 120, 311, 271));
        image->setPixmap(QPixmap(QString::fromUtf8("../template graphique/images/logo 1.png")));
        title = new QLabel(ConsulterStat);
        title->setObjectName(QStringLiteral("title"));
        title->setGeometry(QRect(270, -30, 391, 151));
        OK = new QPushButton(ConsulterStat);
        OK->setObjectName(QStringLiteral("OK"));
        OK->setGeometry(QRect(620, 450, 111, 28));

        retranslateUi(ConsulterStat);

        QMetaObject::connectSlotsByName(ConsulterStat);
    } // setupUi

    void retranslateUi(QDialog *ConsulterStat)
    {
        ConsulterStat->setWindowTitle(QApplication::translate("ConsulterStat", "Statistiques", 0));
        image->setText(QString());
        title->setText(QApplication::translate("ConsulterStat", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#55aaff;\">Statistiques</span></p></body></html>", 0));
        OK->setText(QApplication::translate("ConsulterStat", "OK", 0));
    } // retranslateUi

};

namespace Ui {
    class ConsulterStat: public Ui_ConsulterStat {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONSULTERSTAT_H
