/********************************************************************************
** Form generated from reading UI file 'updateaccountuser.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_UPDATEACCOUNTUSER_H
#define UI_UPDATEACCOUNTUSER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>

QT_BEGIN_NAMESPACE

class Ui_UpdateAccountUser
{
public:
    QDialogButtonBox *buttonBox;
    QLineEdit *newPass;
    QLabel *title;
    QLabel *image;
    QLabel *newPassword_2;
    QLabel *newPassword;
    QLineEdit *newPass2;

    void setupUi(QDialog *UpdateAccountUser)
    {
        if (UpdateAccountUser->objectName().isEmpty())
            UpdateAccountUser->setObjectName(QStringLiteral("UpdateAccountUser"));
        UpdateAccountUser->resize(800, 500);
        buttonBox = new QDialogButtonBox(UpdateAccountUser);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(440, 450, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        newPass = new QLineEdit(UpdateAccountUser);
        newPass->setObjectName(QStringLiteral("newPass"));
        newPass->setGeometry(QRect(640, 220, 141, 22));
        newPass->setEchoMode(QLineEdit::Normal);
        title = new QLabel(UpdateAccountUser);
        title->setObjectName(QStringLiteral("title"));
        title->setGeometry(QRect(250, -30, 391, 151));
        image = new QLabel(UpdateAccountUser);
        image->setObjectName(QStringLiteral("image"));
        image->setGeometry(QRect(20, 120, 311, 271));
        image->setPixmap(QPixmap(QString::fromUtf8("../template graphique/images/logo 1.png")));
        newPassword_2 = new QLabel(UpdateAccountUser);
        newPassword_2->setObjectName(QStringLiteral("newPassword_2"));
        newPassword_2->setGeometry(QRect(310, 260, 341, 51));
        newPassword = new QLabel(UpdateAccountUser);
        newPassword->setObjectName(QStringLiteral("newPassword"));
        newPassword->setGeometry(QRect(310, 190, 301, 81));
        newPass2 = new QLineEdit(UpdateAccountUser);
        newPass2->setObjectName(QStringLiteral("newPass2"));
        newPass2->setGeometry(QRect(640, 280, 141, 22));
        newPass2->setEchoMode(QLineEdit::Normal);

        retranslateUi(UpdateAccountUser);
        QObject::connect(buttonBox, SIGNAL(accepted()), UpdateAccountUser, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), UpdateAccountUser, SLOT(reject()));

        QMetaObject::connectSlotsByName(UpdateAccountUser);
    } // setupUi

    void retranslateUi(QDialog *UpdateAccountUser)
    {
        UpdateAccountUser->setWindowTitle(QApplication::translate("UpdateAccountUser", "Modifier mon compte", 0));
        title->setText(QApplication::translate("UpdateAccountUser", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#55aaff;\">Modifier mon compte</span></p></body></html>", 0));
        image->setText(QString());
        newPassword_2->setText(QApplication::translate("UpdateAccountUser", "<html><head/><body><p><span style=\" font-size:12pt;\">Confirmer le nouveau mot de passe</span></p></body></html>", 0));
        newPassword->setText(QApplication::translate("UpdateAccountUser", "<html><head/><body><p><span style=\" font-size:12pt;\">Saisir le nouveau mot de passe</span></p></body></html>", 0));
    } // retranslateUi

};

namespace Ui {
    class UpdateAccountUser: public Ui_UpdateAccountUser {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UPDATEACCOUNTUSER_H
