/********************************************************************************
** Form generated from reading UI file 'etatactuel.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ETATACTUEL_H
#define UI_ETATACTUEL_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_EtatActuel
{
public:
    QLabel *title;
    QPushButton *OK;
    QLabel *image;
    QPushButton *pushButton;
    QTableView *tableView;

    void setupUi(QDialog *EtatActuel)
    {
        if (EtatActuel->objectName().isEmpty())
            EtatActuel->setObjectName(QStringLiteral("EtatActuel"));
        EtatActuel->resize(800, 500);
        title = new QLabel(EtatActuel);
        title->setObjectName(QStringLiteral("title"));
        title->setGeometry(QRect(270, -40, 391, 151));
        OK = new QPushButton(EtatActuel);
        OK->setObjectName(QStringLiteral("OK"));
        OK->setGeometry(QRect(652, 440, 111, 28));
        image = new QLabel(EtatActuel);
        image->setObjectName(QStringLiteral("image"));
        image->setGeometry(QRect(30, 110, 311, 271));
        image->setPixmap(QPixmap(QString::fromUtf8("../template graphique/images/logo 1.png")));
        pushButton = new QPushButton(EtatActuel);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(170, 400, 191, 41));
        tableView = new QTableView(EtatActuel);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(70, 110, 421, 271));

        retranslateUi(EtatActuel);

        QMetaObject::connectSlotsByName(EtatActuel);
    } // setupUi

    void retranslateUi(QDialog *EtatActuel)
    {
        EtatActuel->setWindowTitle(QApplication::translate("EtatActuel", "Etat actuel du parking", 0));
        title->setText(QApplication::translate("EtatActuel", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#55aaff;\">Etat actuel du parking</span></p></body></html>", 0));
        OK->setText(QApplication::translate("EtatActuel", "OK", 0));
        image->setText(QString());
        pushButton->setText(QApplication::translate("EtatActuel", "Voir etat actuel", 0));
    } // retranslateUi

};

namespace Ui {
    class EtatActuel: public Ui_EtatActuel {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ETATACTUEL_H
