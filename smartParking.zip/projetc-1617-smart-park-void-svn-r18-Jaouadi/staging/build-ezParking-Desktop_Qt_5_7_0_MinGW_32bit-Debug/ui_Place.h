/********************************************************************************
** Form generated from reading UI file 'Place.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PLACE_H
#define UI_PLACE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Place
{
public:
    QPushButton *pushButton;
    QPushButton *load;
    QComboBox *comboBox;
    QPushButton *pushButton_2;

    void setupUi(QDialog *Place)
    {
        if (Place->objectName().isEmpty())
            Place->setObjectName(QStringLiteral("Place"));
        Place->resize(765, 386);
        pushButton = new QPushButton(Place);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(550, 310, 151, 41));
        load = new QPushButton(Place);
        load->setObjectName(QStringLiteral("load"));
        load->setGeometry(QRect(220, 80, 161, 31));
        comboBox = new QComboBox(Place);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(220, 30, 161, 31));
        pushButton_2 = new QPushButton(Place);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(220, 130, 161, 31));

        retranslateUi(Place);

        QMetaObject::connectSlotsByName(Place);
    } // setupUi

    void retranslateUi(QDialog *Place)
    {
        Place->setWindowTitle(QApplication::translate("Place", "Dialog", 0));
        pushButton->setText(QApplication::translate("Place", "Retour", 0));
        load->setText(QApplication::translate("Place", "Charger les place", 0));
        pushButton_2->setText(QApplication::translate("Place", "Supprimer place", 0));
    } // retranslateUi

};

namespace Ui {
    class Place: public Ui_Place {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PLACE_H
