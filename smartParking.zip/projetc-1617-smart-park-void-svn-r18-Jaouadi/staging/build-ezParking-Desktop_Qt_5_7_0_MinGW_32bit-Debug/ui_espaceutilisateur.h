/********************************************************************************
** Form generated from reading UI file 'espaceutilisateur.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ESPACEUTILISATEUR_H
#define UI_ESPACEUTILISATEUR_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_EspaceUtilisateur
{
public:
    QPushButton *parkState;
    QPushButton *updateAcc;
    QPushButton *objectList;
    QLabel *title;
    QLabel *image;

    void setupUi(QDialog *EspaceUtilisateur)
    {
        if (EspaceUtilisateur->objectName().isEmpty())
            EspaceUtilisateur->setObjectName(QStringLiteral("EspaceUtilisateur"));
        EspaceUtilisateur->resize(800, 500);
        parkState = new QPushButton(EspaceUtilisateur);
        parkState->setObjectName(QStringLiteral("parkState"));
        parkState->setGeometry(QRect(540, 260, 181, 41));
        updateAcc = new QPushButton(EspaceUtilisateur);
        updateAcc->setObjectName(QStringLiteral("updateAcc"));
        updateAcc->setGeometry(QRect(540, 200, 181, 41));
        updateAcc->setAutoDefault(true);
        objectList = new QPushButton(EspaceUtilisateur);
        objectList->setObjectName(QStringLiteral("objectList"));
        objectList->setGeometry(QRect(540, 320, 181, 41));
        objectList->setAutoDefault(false);
        title = new QLabel(EspaceUtilisateur);
        title->setObjectName(QStringLiteral("title"));
        title->setGeometry(QRect(230, -30, 481, 181));
        image = new QLabel(EspaceUtilisateur);
        image->setObjectName(QStringLiteral("image"));
        image->setGeometry(QRect(90, 140, 311, 271));
        image->setPixmap(QPixmap(QString::fromUtf8("../template graphique/images/logo 1.png")));

        retranslateUi(EspaceUtilisateur);

        updateAcc->setDefault(false);


        QMetaObject::connectSlotsByName(EspaceUtilisateur);
    } // setupUi

    void retranslateUi(QDialog *EspaceUtilisateur)
    {
        EspaceUtilisateur->setWindowTitle(QApplication::translate("EspaceUtilisateur", "Dialog", 0));
        parkState->setText(QApplication::translate("EspaceUtilisateur", "Voir l'\303\251tat actuel du parking", 0));
        updateAcc->setText(QApplication::translate("EspaceUtilisateur", "Modifier mon compte", 0));
        objectList->setText(QApplication::translate("EspaceUtilisateur", "Consulter la liste des objets", 0));
        title->setText(QApplication::translate("EspaceUtilisateur", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#55aaff;\">Espace Utilisateur</span></p></body></html>", 0));
        image->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class EspaceUtilisateur: public Ui_EspaceUtilisateur {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ESPACEUTILISATEUR_H
