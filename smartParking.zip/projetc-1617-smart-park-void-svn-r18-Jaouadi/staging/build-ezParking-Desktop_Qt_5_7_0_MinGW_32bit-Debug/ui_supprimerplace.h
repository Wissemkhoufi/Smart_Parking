/********************************************************************************
** Form generated from reading UI file 'supprimerplace.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SUPPRIMERPLACE_H
#define UI_SUPPRIMERPLACE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>

QT_BEGIN_NAMESPACE

class Ui_supprimerplace
{
public:

    void setupUi(QDialog *supprimerplace)
    {
        if (supprimerplace->objectName().isEmpty())
            supprimerplace->setObjectName(QStringLiteral("supprimerplace"));
        supprimerplace->resize(752, 359);

        retranslateUi(supprimerplace);

        QMetaObject::connectSlotsByName(supprimerplace);
    } // setupUi

    void retranslateUi(QDialog *supprimerplace)
    {
        supprimerplace->setWindowTitle(QApplication::translate("supprimerplace", "Dialog", 0));
    } // retranslateUi

};

namespace Ui {
    class supprimerplace: public Ui_supprimerplace {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SUPPRIMERPLACE_H
