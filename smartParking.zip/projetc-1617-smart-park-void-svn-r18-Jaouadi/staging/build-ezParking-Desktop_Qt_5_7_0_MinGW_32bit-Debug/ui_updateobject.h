/********************************************************************************
** Form generated from reading UI file 'updateobject.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_UPDATEOBJECT_H
#define UI_UPDATEOBJECT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_UpdateObject
{
public:
    QLabel *decsription;
    QLineEdit *idBox;
    QComboBox *objectList;
    QTextEdit *descBox;
    QLabel *identifiant;
    QLabel *selectObject;
    QLabel *title;
    QDialogButtonBox *buttonBox;
    QLabel *image;
    QLineEdit *idBox_2;
    QLabel *identifiant_2;
    QPushButton *pushButton;

    void setupUi(QDialog *UpdateObject)
    {
        if (UpdateObject->objectName().isEmpty())
            UpdateObject->setObjectName(QStringLiteral("UpdateObject"));
        UpdateObject->resize(800, 500);
        decsription = new QLabel(UpdateObject);
        decsription->setObjectName(QStringLiteral("decsription"));
        decsription->setGeometry(QRect(390, 300, 251, 51));
        idBox = new QLineEdit(UpdateObject);
        idBox->setObjectName(QStringLiteral("idBox"));
        idBox->setGeometry(QRect(620, 160, 113, 22));
        objectList = new QComboBox(UpdateObject);
        objectList->setObjectName(QStringLiteral("objectList"));
        objectList->setGeometry(QRect(620, 110, 111, 22));
        descBox = new QTextEdit(UpdateObject);
        descBox->setObjectName(QStringLiteral("descBox"));
        descBox->setGeometry(QRect(530, 280, 241, 101));
        identifiant = new QLabel(UpdateObject);
        identifiant->setObjectName(QStringLiteral("identifiant"));
        identifiant->setGeometry(QRect(390, 140, 251, 51));
        selectObject = new QLabel(UpdateObject);
        selectObject->setObjectName(QStringLiteral("selectObject"));
        selectObject->setGeometry(QRect(390, 90, 251, 51));
        title = new QLabel(UpdateObject);
        title->setObjectName(QStringLiteral("title"));
        title->setGeometry(QRect(270, -50, 391, 151));
        buttonBox = new QDialogButtonBox(UpdateObject);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(450, 450, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        image = new QLabel(UpdateObject);
        image->setObjectName(QStringLiteral("image"));
        image->setGeometry(QRect(50, 110, 311, 271));
        image->setPixmap(QPixmap(QString::fromUtf8("../template graphique/images/logo 1.png")));
        idBox_2 = new QLineEdit(UpdateObject);
        idBox_2->setObjectName(QStringLiteral("idBox_2"));
        idBox_2->setGeometry(QRect(620, 220, 113, 22));
        identifiant_2 = new QLabel(UpdateObject);
        identifiant_2->setObjectName(QStringLiteral("identifiant_2"));
        identifiant_2->setGeometry(QRect(390, 210, 251, 51));
        pushButton = new QPushButton(UpdateObject);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(740, 100, 51, 41));

        retranslateUi(UpdateObject);

        QMetaObject::connectSlotsByName(UpdateObject);
    } // setupUi

    void retranslateUi(QDialog *UpdateObject)
    {
        UpdateObject->setWindowTitle(QApplication::translate("UpdateObject", "Dialog", 0));
        decsription->setText(QApplication::translate("UpdateObject", "<html><head/><body><p><span style=\" font-size:12pt;\">D\303\251scription</span></p></body></html>", 0));
        identifiant->setText(QApplication::translate("UpdateObject", "<html><head/><body><p><span style=\" font-size:12pt;\">Num place</span></p></body></html>", 0));
        selectObject->setText(QApplication::translate("UpdateObject", "<html><head/><body><p><span style=\" font-size:12pt;\">S\303\251lectionner l'objet</span></p></body></html>", 0));
        title->setText(QApplication::translate("UpdateObject", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#55aaff;\">Modifier une Place</span></p></body></html>", 0));
        image->setText(QString());
        identifiant_2->setText(QApplication::translate("UpdateObject", "<html><head/><body><p><span style=\" font-size:12pt;\">Etat</span></p></body></html>", 0));
        pushButton->setText(QApplication::translate("UpdateObject", "Load", 0));
    } // retranslateUi

};

namespace Ui {
    class UpdateObject: public Ui_UpdateObject {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UPDATEOBJECT_H
