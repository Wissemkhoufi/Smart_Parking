/********************************************************************************
** Form generated from reading UI file 'addobject.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDOBJECT_H
#define UI_ADDOBJECT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_AddObject
{
public:
    QLabel *identifiant_2;
    QLabel *image;
    QLineEdit *identifiant;
    QLabel *title;
    QLabel *decsription;
    QTextEdit *textEdit;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *AddObject)
    {
        if (AddObject->objectName().isEmpty())
            AddObject->setObjectName(QStringLiteral("AddObject"));
        AddObject->resize(800, 500);
        identifiant_2 = new QLabel(AddObject);
        identifiant_2->setObjectName(QStringLiteral("identifiant_2"));
        identifiant_2->setGeometry(QRect(390, 130, 131, 51));
        image = new QLabel(AddObject);
        image->setObjectName(QStringLiteral("image"));
        image->setGeometry(QRect(20, 140, 311, 271));
        image->setPixmap(QPixmap(QString::fromUtf8("../template graphique/images/logo 1.png")));
        identifiant = new QLineEdit(AddObject);
        identifiant->setObjectName(QStringLiteral("identifiant"));
        identifiant->setGeometry(QRect(650, 150, 113, 22));
        title = new QLabel(AddObject);
        title->setObjectName(QStringLiteral("title"));
        title->setGeometry(QRect(260, -10, 391, 151));
        decsription = new QLabel(AddObject);
        decsription->setObjectName(QStringLiteral("decsription"));
        decsription->setGeometry(QRect(380, 250, 251, 51));
        textEdit = new QTextEdit(AddObject);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(530, 240, 241, 111));
        pushButton = new QPushButton(AddObject);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(550, 430, 75, 23));
        pushButton_2 = new QPushButton(AddObject);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(670, 430, 75, 23));

        retranslateUi(AddObject);

        QMetaObject::connectSlotsByName(AddObject);
    } // setupUi

    void retranslateUi(QDialog *AddObject)
    {
        AddObject->setWindowTitle(QApplication::translate("AddObject", "Dialog", 0));
        identifiant_2->setText(QApplication::translate("AddObject", "<html><head/><body><p><span style=\" font-size:12pt;\">numero de place</span></p></body></html>", 0));
        image->setText(QString());
        title->setText(QApplication::translate("AddObject", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#55aaff;\">Ajouter un objet</span></p></body></html>", 0));
        decsription->setText(QApplication::translate("AddObject", "<html><head/><body><p><span style=\" font-size:12pt;\">D\303\251scription</span></p></body></html>", 0));
        pushButton->setText(QApplication::translate("AddObject", "Ok", 0));
        pushButton_2->setText(QApplication::translate("AddObject", "cancel", 0));
    } // retranslateUi

};

namespace Ui {
    class AddObject: public Ui_AddObject {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDOBJECT_H
